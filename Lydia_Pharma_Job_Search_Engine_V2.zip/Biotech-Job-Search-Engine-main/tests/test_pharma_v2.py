from biotech_jobs.models import Job
from biotech_jobs.scoring import score_job, alert_location_eligible, load_profile


def job(company, title, location="US Remote", description=""):
    return Job(company=company, title=title, location=location, url="https://example.com/job", source="test", source_id=title, description=description)


def test_v2_profile_loaded():
    p = load_profile(force=True)
    assert p["profile_status"] == "personalized_ready"
    assert p["scoring_version"] == "pharma-v2"


def test_pharma_strategy_beats_generic_account_role():
    strategy = job("Amgen", "Senior Manager, Commercial Strategy, Oncology",
                   description="Lead cross-functional launch strategy, portfolio planning, market research, and commercialization.")
    generic = job("Illumina", "Account Manager",
                  description="Own territory sales targets and customer relationships.")
    assert score_job(strategy).total > score_job(generic).total


def test_associate_director_is_only_light_stretch():
    ad = job("AstraZeneca", "Associate Director, Commercial Strategy",
             description="Commercial strategy and launch planning in oncology.")
    d = job("AstraZeneca", "Director, Commercial Strategy",
            description="Commercial strategy and launch planning in oncology.")
    assert score_job(ad).seniority_adjustment > score_job(d).seniority_adjustment


def test_foreign_remote_is_excluded_before_remote_allow():
    germany = job("Revolution Medicines", "Senior Oncology Account Manager", "Remote (Germany)")
    us = job("Revolution Medicines", "Senior Oncology Account Manager", "Remote US")
    assert alert_location_eligible(germany) is False
    assert alert_location_eligible(us) is True


def test_major_pharma_gets_industry_bonus():
    pharma = job("Amgen", "Commercial Strategy Manager", description="commercial strategy")
    toolco = job("Zymo Research", "Commercial Strategy Manager", description="commercial strategy")
    assert score_job(pharma).industry_fit > score_job(toolco).industry_fit
