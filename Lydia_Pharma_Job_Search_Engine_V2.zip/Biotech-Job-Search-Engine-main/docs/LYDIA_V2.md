# Lydia Pharma Job Search — V2

V2 is designed after reviewing the first production run. It keeps the validated company collectors intact and changes the ranking/search layer instead.

## What changed

1. **Pharma-first industry weighting.** Major pharma and commercial biopharma receive more weight than life-science tools companies.
2. **Career direction first.** Commercial Strategy / New Product Planning / Launch / Market Development are highest priority, followed by Strategic Accounts, then BD & Partnerships.
3. **Broader discovery.** `ranked_jobs.csv` now exports roles scoring 50+, while `priority_matches.csv` shows 65+ roles.
4. **Separate diagnostic fields.** Output includes `career_direction_score`, `resume_fit_score`, `career_lane`, and `stretch_level` to make the reasoning easier to audit.
5. **Associate Director calibration fixed.** Associate Director is only a light stretch and is evaluated before the broader Director rule.
6. **US location gate fixed.** Foreign roles such as `Remote (Germany)` are excluded before generic remote patterns are considered.
7. **Collectors preserved.** No existing collector implementation was rewritten based on the first run.

## Interpretation

- `career_lane`: Commercial Strategy, Strategic Accounts, BD & Partnerships, or Other.
- `stretch_level`: Core, Stretch, Selective Stretch, Below Target, or Out of Band.
- `career_direction_score`: how much the role advances Lydia toward pharma commercial leadership.
- `resume_fit_score`: evidence-backed adjacency to Lydia's current scientific/business background.
- `total`: combined V2 ranking score.

The first V2 run is still calibration data. Review at least 25–40 roles before making major scoring changes.
